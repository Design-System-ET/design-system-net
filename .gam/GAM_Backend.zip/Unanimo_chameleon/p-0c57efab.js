function n(n){return{name:"VBScript in HTML",subLanguage:"xml",contains:[{begin:"<%",end:"%>",subLanguage:"vbscript"}]}}export{n as default};
//# sourceMappingURL=p-0c57efab.js.map