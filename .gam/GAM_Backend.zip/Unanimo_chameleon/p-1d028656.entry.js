export{C as ch_code_editor}from"./p-edf73e81.js";import"./p-7af91c05.js";
//# sourceMappingURL=p-1d028656.entry.js.map