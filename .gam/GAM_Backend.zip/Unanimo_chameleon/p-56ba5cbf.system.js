System.register([],(function(t){"use strict";return{execute:function(){var n=t("g",(function(){}))}}}));
//# sourceMappingURL=p-56ba5cbf.system.js.map