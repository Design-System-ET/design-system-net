function t(t){return{name:"Plain text",aliases:["text","txt"],disableAutodetect:!0}}export{t as default};
//# sourceMappingURL=p-52e67197.js.map