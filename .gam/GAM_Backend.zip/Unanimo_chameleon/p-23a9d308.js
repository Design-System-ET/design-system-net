const s=(s,o,t)=>s.splice(t,0,o);const o=(s,o)=>s.splice(o,1)[0];export{s as i,o as r};
//# sourceMappingURL=p-23a9d308.js.map